						<!-- Main -->
						<li class="nav-item-header"><div class="text-uppercase font-size-xs line-height-xs">PRINCIPAL</div> <i class="icon-menu" title="Main"></i></li>
						<li class="nav-item">
							<a href="usuarios.php" class="nav-link">
								<i class="icon-home4"></i>
								<span>
									Home
								</span>
							</a>
						</li>
						<li class="nav-item nav-item-submenu">
							<a href="#" class="nav-link"><i class="icon-copy"></i> <span>Usuarios</span></a>

							<ul class="nav nav-group-sub" data-submenu-title="Layouts">
								<li class="nav-item"><a href="usuarios.php" class="nav-link active">Usuarios</a></li>
								<li class="nav-item"><a href="usuarios_agregar.php" class="nav-link active">Agregar Usuario</a></li>
								
							</ul>
						</li>


						<li class="nav-item nav-item-submenu">
							<a href="#" class="nav-link"><i class="icon-copy"></i> <span>Notificaciones</span></a>

							<ul class="nav nav-group-sub" data-submenu-title="Layouts">
								<li class="nav-item"><a href="notificaciones.php" class="nav-link active">Notificaciones</a></li>
								<li class="nav-item"><a href="notificaciones_agregar.php" class="nav-link active">Agregar Notificación</a></li>
								
							</ul>
						</li>

						<!-- /main -->
